<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Dashboard';

// Statistik
$totalUsers   = 0;
$totalDomains = 0;
$totalDB      = 0;
$diskUsage    = '0 MB';
$uptime       = 'N/A';

// Hitung user dari /home
$homeDirs = glob('/home/*', GLOB_ONLYDIR);
$systemDirs = ['root','pma','www','datauser','xcodehoster','datapengguna','domain','checkdata','checkdata2','filemanager'];
foreach ($homeDirs as $d) {
  if (!in_array(basename($d), $systemDirs)) $totalUsers++;
}

// Hitung domain dari apache sites
$domainFiles = glob('/etc/apache2/sites-available/*.conf');
$totalDomains = $domainFiles ? count($domainFiles) : 0;

// Disk usage /home
$du = shell_exec('du -sh /home 2>/dev/null');
if ($du) $diskUsage = explode("\t", $du)[0];

// Uptime
$upCmd = shell_exec('uptime -p 2>/dev/null');
if ($upCmd) $uptime = trim(str_replace('up ', '', $upCmd));

// Voucher tersisa
$voucherCount = 0;
if (file_exists('/usr/lib/cgi-bin/vouchers.txt')) {
  $voucherCount = count(array_filter(explode("\n", file_get_contents('/usr/lib/cgi-bin/vouchers.txt'))));
}

// Aktifitas terbaru dari /home/datapengguna
$recentUsers = [];
$dpFiles = glob('/home/datapengguna/*');
if ($dpFiles) {
  usort($dpFiles, fn($a,$b) => filemtime($b) - filemtime($a));
  foreach (array_slice($dpFiles, 0, 5) as $f) {
    $line = file_get_contents($f);
    $parts = array_map('trim', explode(',', $line));
    $recentUsers[] = [
      'name'  => $parts[0] ?? basename($f),
      'email' => $parts[2] ?? '-',
      'date'  => $parts[4] ?? '-',
    ];
  }
}

include 'layout/header.php';
?>

<div class="grid-4" style="margin-bottom:1.5rem">
  <div class="stat-card">
    <div class="stat-icon">👥</div>
    <div class="stat-value" style="color:var(--accent)"><?= $totalUsers ?></div>
    <div class="stat-label">Total User</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">🌐</div>
    <div class="stat-value" style="color:var(--accent2)"><?= $totalDomains ?></div>
    <div class="stat-label">Domain Aktif</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">🎟️</div>
    <div class="stat-value" style="color:var(--yellow)"><?= $voucherCount ?></div>
    <div class="stat-label">Voucher Tersisa</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">💾</div>
    <div class="stat-value" style="color:var(--green);font-size:1.3rem"><?= $diskUsage ?></div>
    <div class="stat-label">Disk /home</div>
  </div>
</div>

<div class="grid-2">
  <!-- Pendaftaran Terbaru -->
  <div class="card">
    <div class="card-title">Pendaftaran Terbaru</div>
    <?php if ($recentUsers): ?>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Username</th><th>Email</th><th>Tanggal</th></tr></thead>
        <tbody>
        <?php foreach ($recentUsers as $u): ?>
          <tr>
            <td><strong><?= htmlspecialchars($u['name']) ?></strong></td>
            <td style="color:var(--muted);font-size:.8rem"><?= htmlspecialchars($u['email']) ?></td>
            <td style="font-size:.78rem;font-family:'Space Mono',monospace"><?= htmlspecialchars($u['date']) ?></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
    <p style="color:var(--muted);font-size:.85rem">Belum ada pendaftaran.</p>
    <?php endif; ?>
  </div>

  <!-- Info Server -->
  <div class="card">
    <div class="card-title">Info Server</div>
    <?php
    $info = [
      'OS'        => shell_exec('lsb_release -d 2>/dev/null | cut -d: -f2') ?: 'N/A',
      'Uptime'    => $uptime,
      'PHP'       => phpversion(),
      'Apache'    => shell_exec('apache2 -v 2>/dev/null | head -1') ?: 'N/A',
      'MySQL'     => shell_exec('mysql --version 2>/dev/null') ?: 'N/A',
      'IP Server' => shell_exec('curl -s ifconfig.me 2>/dev/null') ?: 'N/A',
    ];
    ?>
    <table>
      <?php foreach ($info as $k => $v): ?>
      <tr>
        <td style="color:var(--muted);font-size:.78rem;font-family:'Space Mono',monospace;width:110px"><?= $k ?></td>
        <td style="font-size:.82rem"><?= htmlspecialchars(trim($v)) ?></td>
      </tr>
      <?php endforeach; ?>
    </table>
  </div>
</div>

<!-- Quick Actions -->
<div class="card">
  <div class="card-title">Akses Cepat</div>
  <div style="display:flex;gap:.75rem;flex-wrap:wrap">
    <a href="users.php" class="btn btn-secondary">👥 Kelola User</a>
    <a href="domain.php" class="btn btn-secondary">🌐 Kelola Domain</a>
    <a href="database.php" class="btn btn-secondary">🗄️ Kelola Database</a>
    <a href="voucher.php" class="btn btn-secondary">🎟️ Kelola Voucher</a>
    <a href="/phpmyadmin" target="_blank" class="btn btn-secondary">🔧 phpMyAdmin</a>
    <a href="filemanager.php" class="btn btn-secondary">📁 File Manager</a>
  </div>
</div>

<?php include 'layout/footer.php'; ?>
