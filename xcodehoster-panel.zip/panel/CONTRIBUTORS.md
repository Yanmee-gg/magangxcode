# PENGEMBANG XCODEHOSTER PANEL

## Tim Inti X-Code Media
- **Kurniawan** — Lead Developer, Back End
  Email: kurniawanajazenfone@gmail.com
  Web: xcode.or.id / xcode.co.id

- **Hermawan** — Front End Designer
  Email: hermawan9815@gmail.com

## Tim Magang (Intern Developers)
- **Wayan Juliana** — PHP Panel Developer
  Institusi: Politeknik Negeri Lampung
  Tahun: 2025
  Kontribusi: Konversi bash installer ke PHP, Web Installer, Panel Hosting Mini

## Tentang Aplikasi
Xcodehoster Panel adalah panel hosting mini berbasis PHP
yang dikembangkan oleh X-Code Media sebagai bagian dari
program magang Politeknik Negeri Lampung.

Aplikasi ini merupakan pengembangan dari Xcodehoster v11
yang awalnya berbasis Bash Script, dikonversi ke PHP
untuk kemudahan penggunaan dan pemeliharaan.

## Lisensi
GNU General Public License v3 (GPL v3)
Lihat file LICENSE untuk detail lengkap.

Referensi lisensi file manager:
https://github.com/kurniawandata/xcodehoster/blob/main/filemanager/LICENSE
