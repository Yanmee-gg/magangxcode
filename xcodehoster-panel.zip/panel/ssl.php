<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'SSL Manager';

$msg = ''; $msgType = '';

// Upload sertifikat manual
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload_ssl') {
  $domain = preg_replace('/[^a-zA-Z0-9\.\-]/', '', trim($_POST['domain'] ?? ''));
  $pem = trim($_POST['pem'] ?? '');
  $key = trim($_POST['key'] ?? '');
  if ($domain && $pem && $key) {
    @mkdir(SSL_DIR, 0777, true);
    file_put_contents(SSL_DIR . "/$domain.pem", $pem);
    file_put_contents(SSL_DIR . "/$domain.key", $key);
    // Update vhost jika ada
    $confFile = APACHE_SITES . "/$domain.conf";
    if (!file_exists($confFile)) {
      $vhost = "<VirtualHost *:443>
    ServerName $domain
    DocumentRoot /var/www/html
    SSLEngine on
    SSLCertificateFile " . SSL_DIR . "/$domain.pem
    SSLCertificateKeyFile " . SSL_DIR . "/$domain.key
    <Directory /var/www/html>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>";
      file_put_contents($confFile, $vhost);
      runCmd("a2ensite $domain.conf");
    }
    runCmd("service apache2 restart");
    $msg = "Sertifikat SSL untuk $domain berhasil diupload."; $msgType = 'success';
  } else { $msg = 'Semua field harus diisi.'; $msgType = 'error'; }
}

// Generate SSL dengan Certbot
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'certbot') {
  $domain = preg_replace('/[^a-zA-Z0-9\.\-]/', '', trim($_POST['certbot_domain'] ?? ''));
  $email  = trim($_POST['certbot_email'] ?? '');
  if ($domain && $email) {
    $r = runCmd("certbot certonly --webroot -w /var/www/html -d $domain --email $email --agree-tos --non-interactive 2>&1");
    if ($r['code'] === 0) {
      $msg = "SSL Certbot berhasil digenerate untuk $domain."; $msgType = 'success';
    } else {
      $msg = "Gagal: " . $r['output']; $msgType = 'error';
    }
  } else { $msg = 'Domain dan email harus diisi.'; $msgType = 'error'; }
}

// Hapus SSL
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_ssl') {
  $domain = preg_replace('/[^a-zA-Z0-9\.\-]/', '', trim($_POST['domain'] ?? ''));
  if ($domain) {
    runCmd("rm -f " . SSL_DIR . "/$domain.pem " . SSL_DIR . "/$domain.key");
    $msg = "Sertifikat untuk $domain dihapus."; $msgType = 'success';
  }
}

// Daftar sertifikat
$certs = [];
$pemFiles = glob(SSL_DIR . '/*.pem') ?: [];
foreach ($pemFiles as $pf) {
  $domain = basename($pf, '.pem');
  $hasKey = file_exists(SSL_DIR . "/$domain.key");
  // Cek expiry
  $expiry = 'N/A';
  $expiryRaw = shell_exec("openssl x509 -enddate -noout -in $pf 2>/dev/null");
  if ($expiryRaw) {
    preg_match('/notAfter=(.+)/', $expiryRaw, $m);
    $expiry = $m[1] ?? 'N/A';
  }
  $certs[] = ['domain' => $domain, 'hasKey' => $hasKey, 'expiry' => $expiry];
}

include 'layout/header.php';
?>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="grid-2">
<!-- Upload Manual -->
<div class="card">
  <div class="card-title">Upload Sertifikat SSL Manual</div>
  <form method="POST">
    <input type="hidden" name="action" value="upload_ssl">
    <div class="form-group">
      <label>Nama Domain</label>
      <input type="text" name="domain" placeholder="yanlie.my.id" required>
    </div>
    <div class="form-group">
      <label>Isi File .pem (Certificate)</label>
      <textarea name="pem" placeholder="-----BEGIN CERTIFICATE-----&#10;...&#10;-----END CERTIFICATE-----" required></textarea>
    </div>
    <div class="form-group">
      <label>Isi File .key (Private Key)</label>
      <textarea name="key" placeholder="-----BEGIN PRIVATE KEY-----&#10;...&#10;-----END PRIVATE KEY-----" required></textarea>
    </div>
    <button type="submit" class="btn btn-primary">🔒 Upload SSL</button>
  </form>
</div>

<!-- Certbot -->
<div class="card">
  <div class="card-title">Generate SSL Gratis (Certbot)</div>
  <div class="alert alert-info" style="font-size:.78rem;margin-bottom:1rem">
    ℹ Pastikan domain sudah mengarah ke IP server ini sebelum generate SSL.
  </div>
  <form method="POST">
    <input type="hidden" name="action" value="certbot">
    <div class="form-group">
      <label>Domain</label>
      <input type="text" name="certbot_domain" placeholder="yanlie.my.id" required>
    </div>
    <div class="form-group">
      <label>Email</label>
      <input type="email" name="certbot_email" placeholder="email@domain.com" required>
    </div>
    <button type="submit" class="btn btn-primary">⚡ Generate SSL Gratis</button>
  </form>
</div>
</div>

<!-- Daftar Sertifikat -->
<div class="card">
  <div class="card-title" style="justify-content:space-between">
    <span style="display:flex;align-items:center;gap:.5rem"><span style="width:3px;height:14px;background:var(--accent);border-radius:2px;display:block"></span>Sertifikat Terpasang</span>
    <span class="badge badge-blue"><?= count($certs) ?> sertifikat</span>
  </div>
  <?php if (empty($certs)): ?>
  <p style="color:var(--muted);font-size:.85rem;text-align:center;padding:2rem">Belum ada sertifikat SSL.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Domain</th><th>Key</th><th>Berlaku Hingga</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($certs as $i => $c): ?>
        <tr>
          <td style="color:var(--muted)"><?= $i+1 ?></td>
          <td><strong><?= htmlspecialchars($c['domain']) ?></strong></td>
          <td><?= $c['hasKey'] ? '<span class="badge badge-green">✔ Ada</span>' : '<span class="badge badge-red">✖ Tidak Ada</span>' ?></td>
          <td style="font-size:.78rem;font-family:\'Space Mono\',monospace"><?= htmlspecialchars($c['expiry']) ?></td>
          <td>
            <form method="POST" style="display:inline" onsubmit="return confirm('Hapus sertifikat ini?')">
              <input type="hidden" name="action" value="delete_ssl">
              <input type="hidden" name="domain" value="<?= htmlspecialchars($c['domain']) ?>">
              <button type="submit" class="btn btn-danger btn-sm">🗑️</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php include 'layout/footer.php'; ?>
