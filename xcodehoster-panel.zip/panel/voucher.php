<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Voucher Manager';

$msg = ''; $msgType = '';
$voucherFile = CGI_BIN . '/vouchers.txt';

// Generate voucher baru
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'generate') {
  $count  = min(max((int)($_POST['count'] ?? 1000), 1), 5000);
  $length = min(max((int)($_POST['length'] ?? 8), 4), 16);
  $chars  = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  $vouchers = [];
  for ($i = 0; $i < $count; $i++) {
    $v = '';
    for ($j = 0; $j < $length; $j++) $v .= $chars[random_int(0, 61)];
    $vouchers[] = $v;
  }
  $content = implode("\n", $vouchers);
  file_put_contents($voucherFile, $content);
  // Simpan salinan publik
  $rand = str_pad(rand(0, 999), 3, '0', STR_PAD_LEFT);
  $pubFile = "/home/xcodehoster/vouchers{$rand}.txt";
  file_put_contents($pubFile, $content);
  $msg = "$count voucher berhasil digenerate. File publik: vouchers{$rand}.txt"; $msgType = 'success';
}

// Hapus semua voucher
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'clear') {
  file_put_contents($voucherFile, '');
  $msg = 'Semua voucher dihapus.'; $msgType = 'success';
}

// Tambah voucher manual
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_manual') {
  $newVouchers = array_filter(array_map('trim', explode("\n", $_POST['manual'] ?? '')));
  $existing = file_exists($voucherFile) ? array_filter(explode("\n", file_get_contents($voucherFile))) : [];
  $merged = array_unique(array_merge($existing, $newVouchers));
  file_put_contents($voucherFile, implode("\n", $merged));
  $msg = count($newVouchers) . ' voucher ditambahkan.'; $msgType = 'success';
}

// Baca voucher
$vouchers = [];
if (file_exists($voucherFile)) {
  $vouchers = array_values(array_filter(array_map('trim', explode("\n", file_get_contents($voucherFile)))));
}
$totalVouchers = count($vouchers);
$page = max(1, (int)($_GET['page'] ?? 1));
$perPage = 50;
$totalPages = max(1, ceil($totalVouchers / $perPage));
$page = min($page, $totalPages);
$pageVouchers = array_slice($vouchers, ($page-1)*$perPage, $perPage);

include 'layout/header.php';
?>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<!-- Statistik -->
<div class="grid-3" style="margin-bottom:1.5rem">
  <div class="stat-card">
    <div class="stat-icon">🎟️</div>
    <div class="stat-value" style="color:var(--accent)"><?= $totalVouchers ?></div>
    <div class="stat-label">Total Voucher</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">📄</div>
    <div class="stat-value" style="color:var(--accent2)"><?= $totalPages ?></div>
    <div class="stat-label">Halaman</div>
  </div>
  <div class="stat-card">
    <div class="stat-icon">💾</div>
    <div class="stat-value" style="color:var(--green);font-size:1.2rem"><?= file_exists($voucherFile) ? round(filesize($voucherFile)/1024, 1) . ' KB' : '0 KB' ?></div>
    <div class="stat-label">Ukuran File</div>
  </div>
</div>

<div class="grid-2">
<!-- Generate -->
<div class="card">
  <div class="card-title">Generate Voucher Baru</div>
  <form method="POST">
    <input type="hidden" name="action" value="generate">
    <div class="form-group">
      <label>Jumlah Voucher</label>
      <input type="number" name="count" value="1000" min="1" max="5000">
    </div>
    <div class="form-group">
      <label>Panjang Voucher (karakter)</label>
      <input type="number" name="length" value="8" min="4" max="16">
    </div>
    <div style="display:flex;gap:.75rem">
      <button type="submit" class="btn btn-primary">⚡ Generate</button>
      <button type="submit" form="clearForm" class="btn btn-danger" onclick="return confirm('Hapus semua voucher?')">🗑️ Kosongkan</button>
    </div>
  </form>
  <form method="POST" id="clearForm"><input type="hidden" name="action" value="clear"></form>
</div>

<!-- Tambah Manual -->
<div class="card">
  <div class="card-title">Tambah Voucher Manual</div>
  <form method="POST">
    <input type="hidden" name="action" value="add_manual">
    <div class="form-group">
      <label>Voucher (satu per baris)</label>
      <textarea name="manual" placeholder="VOUCHER001&#10;VOUCHER002&#10;VOUCHER003" style="min-height:120px"></textarea>
    </div>
    <button type="submit" class="btn btn-primary">➕ Tambah</button>
  </form>
</div>
</div>

<!-- Daftar Voucher -->
<div class="card">
  <div class="card-title" style="justify-content:space-between">
    <span style="display:flex;align-items:center;gap:.5rem"><span style="width:3px;height:14px;background:var(--accent);border-radius:2px;display:block"></span>Daftar Voucher</span>
    <span class="badge badge-blue">Hal <?= $page ?>/<?= $totalPages ?></span>
  </div>

  <?php if (empty($vouchers)): ?>
  <p style="color:var(--muted);font-size:.85rem;text-align:center;padding:2rem">Belum ada voucher.</p>
  <?php else: ?>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:.5rem;margin-bottom:1rem">
    <?php foreach ($pageVouchers as $v): ?>
    <div style="background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:6px;padding:.4rem .7rem;font-family:'Space Mono',monospace;font-size:.8rem;text-align:center"><?= htmlspecialchars($v) ?></div>
    <?php endforeach; ?>
  </div>

  <!-- Pagination -->
  <div style="display:flex;gap:.4rem;justify-content:center;flex-wrap:wrap">
    <?php for ($p = max(1,$page-3); $p <= min($totalPages,$page+3); $p++): ?>
    <a href="?page=<?= $p ?>" class="btn btn-sm <?= $p === $page ? 'btn-primary' : 'btn-secondary' ?>"><?= $p ?></a>
    <?php endfor; ?>
  </div>
  <?php endif; ?>
</div>

<?php include 'layout/footer.php'; ?>
