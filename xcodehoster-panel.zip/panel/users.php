<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Manajemen User';

$msg = ''; $msgType = '';

// Hapus user
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
  $name = preg_replace('/[^a-z0-9]/', '', strtolower(trim($_POST['name'] ?? '')));
  if ($name) {
    runCmd("a2dissite $name.conf");
    runCmd("rm -f /etc/apache2/sites-available/$name.conf");
    runCmd("rm -rf /home/$name");
    runCmd("rm -f /home/datapengguna/$name.*");
    runCmd("rm -f /home/checkdata2/$name.*");
    runCmd("mysql -uroot -e \"DROP USER IF EXISTS '$name'@'localhost'; DROP DATABASE IF EXISTS \`$name\`;\"");
    runCmd("service apache2 reload");
    $msg = "User '$name' berhasil dihapus."; $msgType = 'success';
  }
}

// Ambil daftar user dari /home/datapengguna
$users = [];
$systemDirs = ['root','pma','www','datauser','xcodehoster','datapengguna','domain','checkdata','checkdata2','filemanager','recovery'];
$dpFiles = glob('/home/datapengguna/*') ?: [];
foreach ($dpFiles as $f) {
  $line = trim(file_get_contents($f));
  $parts = array_map('trim', explode(',', $line));
  $name = $parts[0] ?? basename($f);
  $name = preg_replace('/[^a-z0-9]/', '', strtolower($name));
  if (!$name || in_array($name, $systemDirs)) continue;
  $users[] = [
    'name'   => $name,
    'email'  => $parts[2] ?? '-',
    'wa'     => $parts[3] ?? '-',
    'date'   => $parts[4] ?? '-',
    'active' => is_dir("/home/$name"),
    'domain' => file_exists("/etc/apache2/sites-available/$name.conf"),
  ];
}

include 'layout/header.php';
?>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="card">
  <div class="card-title" style="justify-content:space-between;display:flex;align-items:center">
    <span style="display:flex;align-items:center;gap:.5rem"><span style="width:3px;height:14px;background:var(--accent);border-radius:2px;display:block"></span>Daftar User Hosting</span>
    <span class="badge badge-blue"><?= count($users) ?> user</span>
  </div>

  <?php if (empty($users)): ?>
  <p style="color:var(--muted);font-size:.85rem;text-align:center;padding:2rem">Belum ada user terdaftar.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>Username</th>
          <th>Email</th>
          <th>WhatsApp</th>
          <th>Tanggal Daftar</th>
          <th>Status</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($users as $i => $u): ?>
        <tr>
          <td style="color:var(--muted)"><?= $i+1 ?></td>
          <td>
            <strong><?= htmlspecialchars($u['name']) ?></strong><br>
            <span style="font-size:.72rem;color:var(--muted);font-family:'Space Mono',monospace"><?= htmlspecialchars($u['name']) ?>.<?= defined('MAIN_DOMAIN') ? MAIN_DOMAIN : 'domain.com' ?></span>
          </td>
          <td style="font-size:.82rem"><?= htmlspecialchars($u['email']) ?></td>
          <td style="font-size:.82rem;font-family:'Space Mono',monospace"><?= htmlspecialchars($u['wa']) ?></td>
          <td style="font-size:.78rem;font-family:'Space Mono',monospace"><?= htmlspecialchars($u['date']) ?></td>
          <td>
            <?php if ($u['active']): ?>
              <span class="badge badge-green">✔ Aktif</span>
            <?php else: ?>
              <span class="badge badge-red">✖ Tidak Aktif</span>
            <?php endif; ?>
            <?php if ($u['domain']): ?>
              <span class="badge badge-blue" style="margin-left:.25rem">Domain</span>
            <?php endif; ?>
          </td>
          <td>
            <div style="display:flex;gap:.4rem">
              <a href="filemanager.php?user=<?= urlencode($u['name']) ?>" class="btn btn-secondary btn-sm">📁</a>
              <button onclick="confirmDelete('<?= htmlspecialchars($u['name']) ?>')" class="btn btn-danger btn-sm">🗑️</button>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<!-- Modal Konfirmasi Hapus -->
<div class="modal-overlay" id="modalDelete">
  <div class="modal">
    <div class="modal-title">⚠️ Hapus User</div>
    <p style="color:var(--muted);margin-bottom:1rem;font-size:.9rem">
      Apakah Anda yakin ingin menghapus user <strong id="deleteUsername" style="color:var(--red)"></strong>?<br>
      <span style="font-size:.82rem">Semua data, file, database, dan domain akan ikut dihapus.</span>
    </p>
    <form method="POST" id="deleteForm">
      <input type="hidden" name="action" value="delete">
      <input type="hidden" name="name" id="deleteNameInput">
      <div class="modal-actions">
        <button type="button" onclick="closeModal('modalDelete')" class="btn btn-secondary">Batal</button>
        <button type="submit" class="btn btn-danger">Ya, Hapus</button>
      </div>
    </form>
  </div>
</div>

<script>
function confirmDelete(name) {
  document.getElementById('deleteUsername').textContent = name;
  document.getElementById('deleteNameInput').value = name;
  openModal('modalDelete');
}
</script>

<?php include 'layout/footer.php'; ?>
