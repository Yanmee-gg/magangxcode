# Xcodehoster Panel

Panel hosting mini berbasis PHP, pengembangan dari Xcodehoster v11.

**GNU General Public License v3 — xcode.or.id**

## Fitur
- 🔐 Login Admin
- ⊞ Dashboard (statistik server, user, domain)
- 👥 Manajemen User (lihat, hapus user hosting)
- 🌐 Domain Manager (tambah/hapus subdomain + Cloudflare DNS)
- 🗄️ Database Manager (buat/hapus MySQL database & user)
- 📁 File Manager (browse, upload, edit, hapus file)
- 🔒 SSL Manager (upload manual / Certbot)
- 🎟️ Voucher Manager (generate, tambah, kelola voucher)
- ℹ️ Halaman Tentang + Lisensi + Kontributor

## Instalasi

```bash
# Clone repo
git clone https://github.com/Yanmee-gg/magangxcode
cd magangxcode

# Salin panel ke web root
cp -r panel /var/www/html/panel

# Set permission
chmod 755 /var/www/html/panel
chmod 644 /var/www/html/panel/*.php

# Akses di browser
http://IP_SERVER/panel/
```

## Login Default
- Username: `admin`
- Password: `admin123`

> ⚠️ Segera ganti password di file `.admin_pass` setelah login pertama!

```bash
echo "passwordbaru" > /var/www/html/panel/.admin_pass
```

## Pengembang

### Tim Inti X-Code Media
- **Kurniawan** — Lead Developer (kurniawanajazenfone@gmail.com)
- **Hermawan** — Front End Designer (hermawan9815@gmail.com)

### Tim Magang
- **Wayan Juliana** — PHP Panel Developer, Politeknik Negeri Lampung (2025)

## Lisensi

GNU General Public License v3 (GPL v3)

File manager component: https://github.com/kurniawandata/xcodehoster/blob/main/filemanager/LICENSE
