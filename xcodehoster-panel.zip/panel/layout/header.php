<?php
// layout/header.php — dipanggil oleh semua halaman panel
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$menuItems = [
    'dashboard'  => ['icon'=>'⊞',  'label'=>'Dashboard'],
    'users'      => ['icon'=>'👥', 'label'=>'Manajemen User'],
    'domain'     => ['icon'=>'🌐', 'label'=>'Domain Manager'],
    'database'   => ['icon'=>'🗄️', 'label'=>'Database Manager'],
    'filemanager'=> ['icon'=>'📁', 'label'=>'File Manager'],
    'ssl'        => ['icon'=>'🔒', 'label'=>'SSL Manager'],
    'voucher'    => ['icon'=>'🎟️', 'label'=>'Voucher'],
    'about'      => ['icon'=>'ℹ️',  'label'=>'Tentang'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= $pageTitle ?? 'Panel' ?> — Xcodehoster</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=Space+Mono&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#07090f;--sidebar:#0b0f1a;--panel:#0d1117;
  --border:#1c2433;--accent:#2dd4bf;--accent2:#818cf8;
  --text:#f1f5f9;--muted:#64748b;--red:#f87171;
  --green:#34d399;--yellow:#fbbf24;--sidebar-w:240px;
}
body{font-family:'Outfit',sans-serif;background:var(--bg);color:var(--text);display:flex;min-height:100vh}

/* Sidebar */
.sidebar{
  width:var(--sidebar-w);min-width:var(--sidebar-w);
  background:var(--sidebar);border-right:1px solid var(--border);
  display:flex;flex-direction:column;position:fixed;
  top:0;left:0;height:100vh;z-index:100;
}
.sidebar-brand{
  padding:1.5rem 1.25rem 1rem;
  border-bottom:1px solid var(--border);
}
.sidebar-brand .logo{
  display:flex;align-items:center;gap:.75rem;
}
.logo-icon{
  width:36px;height:36px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  border-radius:8px;display:flex;align-items:center;
  justify-content:center;font-size:1rem;flex-shrink:0;
}
.logo-text{font-size:1rem;font-weight:800;letter-spacing:-.02em}
.logo-text span{color:var(--accent)}
.sidebar-version{
  font-size:.7rem;color:var(--muted);
  font-family:'Space Mono',monospace;margin-top:.25rem;
}
.sidebar-nav{flex:1;padding:1rem 0;overflow-y:auto}
.nav-item a{
  display:flex;align-items:center;gap:.75rem;
  padding:.6rem 1.25rem;color:var(--muted);
  text-decoration:none;font-size:.875rem;font-weight:500;
  transition:all .15s;border-left:3px solid transparent;
}
.nav-item a:hover{color:var(--text);background:rgba(255,255,255,.04)}
.nav-item.active a{
  color:var(--accent);background:rgba(45,212,191,.08);
  border-left-color:var(--accent);
}
.nav-icon{font-size:1rem;width:20px;text-align:center}
.sidebar-footer{
  padding:1rem 1.25rem;border-top:1px solid var(--border);
}
.sidebar-user{
  display:flex;align-items:center;gap:.75rem;
  margin-bottom:.75rem;
}
.user-avatar{
  width:32px;height:32px;background:linear-gradient(135deg,var(--accent),var(--accent2));
  border-radius:50%;display:flex;align-items:center;justify-content:center;
  font-size:.8rem;font-weight:700;color:#000;flex-shrink:0;
}
.user-info .name{font-size:.85rem;font-weight:600}
.user-info .role{font-size:.7rem;color:var(--muted);font-family:'Space Mono',monospace}
.btn-logout{
  display:block;width:100%;padding:.5rem;
  background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.2);
  border-radius:6px;color:var(--red);font-size:.8rem;
  text-align:center;text-decoration:none;font-weight:600;
  transition:all .15s;
}
.btn-logout:hover{background:rgba(248,113,113,.2)}

/* Main */
.main{margin-left:var(--sidebar-w);flex:1;display:flex;flex-direction:column;min-height:100vh}
.topbar{
  background:var(--panel);border-bottom:1px solid var(--border);
  padding:.875rem 2rem;display:flex;align-items:center;
  justify-content:space-between;position:sticky;top:0;z-index:50;
}
.topbar-title{font-size:1.1rem;font-weight:700}
.topbar-info{font-size:.75rem;color:var(--muted);font-family:'Space Mono',monospace}
.content{padding:2rem;flex:1}

/* Cards & Components */
.card{background:var(--panel);border:1px solid var(--border);border-radius:12px;padding:1.5rem;margin-bottom:1.5rem}
.card-title{font-size:.8rem;font-weight:600;color:var(--accent);text-transform:uppercase;letter-spacing:.1em;margin-bottom:1.25rem;display:flex;align-items:center;gap:.5rem}
.card-title::before{content:'';display:block;width:3px;height:14px;background:var(--accent);border-radius:2px}
.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:1.5rem}
.grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:1.5rem}
.grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:1.5rem}
.stat-card{background:var(--panel);border:1px solid var(--border);border-radius:12px;padding:1.25rem}
.stat-icon{font-size:1.5rem;margin-bottom:.5rem}
.stat-value{font-size:1.8rem;font-weight:800;margin-bottom:.15rem}
.stat-label{font-size:.78rem;color:var(--muted);font-family:'Space Mono',monospace}

/* Form */
.form-group{margin-bottom:1rem}
.form-group label{display:block;font-size:.78rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;margin-bottom:.4rem;font-family:'Space Mono',monospace}
.form-group input,.form-group select,.form-group textarea{width:100%;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:8px;padding:.65rem .9rem;color:var(--text);font-family:'Space Mono',monospace;font-size:.85rem;transition:border-color .2s,box-shadow .2s}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{outline:none;border-color:var(--accent);box-shadow:0 0 0 3px rgba(45,212,191,.1)}
.form-group select option{background:#1a1f2e}
.form-group textarea{resize:vertical;min-height:80px}

/* Buttons */
.btn{display:inline-flex;align-items:center;gap:.4rem;padding:.55rem 1.1rem;border-radius:7px;font-family:'Outfit',sans-serif;font-weight:600;font-size:.85rem;cursor:pointer;border:none;transition:all .15s;text-decoration:none}
.btn-primary{background:linear-gradient(135deg,var(--accent),#0d9488);color:#000}
.btn-primary:hover{opacity:.9}
.btn-danger{background:rgba(248,113,113,.15);border:1px solid rgba(248,113,113,.3);color:var(--red)}
.btn-danger:hover{background:rgba(248,113,113,.25)}
.btn-secondary{background:rgba(255,255,255,.07);border:1px solid var(--border);color:var(--text)}
.btn-secondary:hover{background:rgba(255,255,255,.12)}
.btn-sm{padding:.35rem .7rem;font-size:.78rem}

/* Table */
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:.85rem}
th{text-align:left;padding:.6rem .9rem;font-size:.72rem;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.08em;border-bottom:1px solid var(--border);font-family:'Space Mono',monospace}
td{padding:.7rem .9rem;border-bottom:1px solid rgba(255,255,255,.04);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}

/* Badge */
.badge{display:inline-flex;align-items:center;padding:.2rem .55rem;border-radius:99px;font-size:.72rem;font-weight:600;font-family:'Space Mono',monospace}
.badge-green{background:rgba(52,211,153,.15);color:var(--green)}
.badge-red{background:rgba(248,113,113,.15);color:var(--red)}
.badge-yellow{background:rgba(251,191,36,.15);color:var(--yellow)}
.badge-blue{background:rgba(129,140,248,.15);color:var(--accent2)}

/* Alert */
.alert{padding:.75rem 1rem;border-radius:8px;font-size:.85rem;margin-bottom:1rem;font-family:'Space Mono',monospace}
.alert-success{background:rgba(52,211,153,.1);border:1px solid rgba(52,211,153,.3);color:var(--green)}
.alert-error{background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.3);color:var(--red)}
.alert-info{background:rgba(45,212,191,.08);border:1px solid rgba(45,212,191,.2);color:var(--accent)}

/* Modal */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.7);z-index:200;align-items:center;justify-content:center}
.modal-overlay.active{display:flex}
.modal{background:var(--panel);border:1px solid var(--border);border-radius:16px;padding:2rem;width:100%;max-width:480px;max-height:90vh;overflow-y:auto}
.modal-title{font-size:1.1rem;font-weight:700;margin-bottom:1.5rem}
.modal-actions{display:flex;gap:.75rem;justify-content:flex-end;margin-top:1.5rem}

/* Responsive */
@media(max-width:768px){
  .sidebar{transform:translateX(-100%);transition:transform .3s}
  .sidebar.open{transform:translateX(0)}
  .main{margin-left:0}
  .grid-2,.grid-3,.grid-4{grid-template-columns:1fr}
  .content{padding:1rem}
}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sidebar-brand">
    <div class="logo">
      <div class="logo-icon">🖥️</div>
      <div>
        <div class="logo-text">Xcode<span>Hoster</span></div>
        <div class="sidebar-version">Panel v<?= PANEL_VERSION ?></div>
      </div>
    </div>
  </div>
  <nav class="sidebar-nav">
    <?php foreach ($menuItems as $page => $item): ?>
    <div class="nav-item <?= $currentPage === $page ? 'active' : '' ?>">
      <a href="<?= $page ?>.php">
        <span class="nav-icon"><?= $item['icon'] ?></span>
        <?= $item['label'] ?>
      </a>
    </div>
    <?php endforeach; ?>
  </nav>
  <div class="sidebar-footer">
    <div class="sidebar-user">
      <div class="user-avatar">A</div>
      <div class="user-info">
        <div class="name">Admin</div>
        <div class="role">Administrator</div>
      </div>
    </div>
    <a href="logout.php" class="btn-logout">⏻ Keluar</a>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <div class="topbar-title"><?= $pageTitle ?? 'Panel' ?></div>
    <div class="topbar-info"><?= date('d M Y, H:i') ?> WIB</div>
  </div>
  <div class="content">
