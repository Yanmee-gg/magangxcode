<?php
// layout/header.php — Xcodehoster Panel · Tema Merah-Putih-Hitam
$currentPage = basename($_SERVER['PHP_SELF'], '.php');
$menuItems = [
    'dashboard'   => ['icon'=>'⊞',  'label'=>'Dashboard'],
    'users'       => ['icon'=>'👥', 'label'=>'Manajemen User'],
    'domain'      => ['icon'=>'🌐', 'label'=>'Domain Manager'],
    'database'    => ['icon'=>'🗄️', 'label'=>'Database Manager'],
    'filemanager' => ['icon'=>'📁', 'label'=>'File Manager'],
    'ssl'         => ['icon'=>'🔒', 'label'=>'SSL Manager'],
    'voucher'     => ['icon'=>'🎟️', 'label'=>'Voucher'],
    'about'       => ['icon'=>'ℹ️',  'label'=>'Tentang'],
];
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle ?? 'Panel') ?> — Xcodehoster</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800;900&family=Barlow:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --black:#0a0a0a; --black2:#0f0f0f; --black3:#141414; --black4:#1a1a1a;
  --red:#e01e1e; --red-dark:#b51515; --red-mute:rgba(224,30,30,.12);
  --red-glow:rgba(224,30,30,.25);
  --white:#f5f5f5; --white-dim:#999; --border:#222; --border2:#2a2a2a;
  --sidebar-w:230px;
}
body{font-family:'Barlow',sans-serif;background:var(--black);color:var(--white);display:flex;min-height:100vh}

/* ── SIDEBAR ─────────────────────────────────── */
.sidebar{
  width:var(--sidebar-w);min-width:var(--sidebar-w);
  background:var(--black2);
  border-right:1px solid var(--border);
  display:flex;flex-direction:column;
  position:fixed;top:0;left:0;height:100vh;z-index:100;
}

/* Red stripe top */
.sidebar::before{content:'';display:block;height:3px;background:var(--red);flex-shrink:0}

.sidebar-brand{
  padding:1.25rem 1.1rem .9rem;
  border-bottom:1px solid var(--border);
}
.brand-row{display:flex;align-items:center;gap:.65rem}
.brand-logo{
  width:38px;height:38px;flex-shrink:0;
  background:var(--black4);
  border:1.5px solid var(--red);
  border-radius:9px;
  display:flex;align-items:center;justify-content:center;
  font-size:1.1rem;
  box-shadow:0 0 12px var(--red-glow);
  overflow:hidden;padding:2px;
}
.brand-logo img{width:100%;height:100%;object-fit:contain;border-radius:6px}
.brand-text .name{
  font-family:'Barlow Condensed',sans-serif;
  font-size:1.1rem;font-weight:900;
  text-transform:uppercase;letter-spacing:.04em;line-height:1;
}
.brand-text .name .r{color:var(--red)}
.brand-text .ver{font-size:.65rem;color:var(--white-dim);letter-spacing:.1em;margin-top:.1rem}

/* Nav */
.sidebar-nav{flex:1;padding:.75rem 0;overflow-y:auto}
.nav-section-label{
  font-size:.62rem;font-weight:700;color:#444;
  text-transform:uppercase;letter-spacing:.15em;
  padding:.6rem 1.1rem .3rem;
}
.nav-item a{
  display:flex;align-items:center;gap:.65rem;
  padding:.55rem 1.1rem;
  color:var(--white-dim);text-decoration:none;
  font-size:.85rem;font-weight:500;
  transition:all .15s;
  border-left:3px solid transparent;
  position:relative;
}
.nav-item a:hover{color:var(--white);background:rgba(255,255,255,.04)}
.nav-item.active a{
  color:var(--white);
  background:var(--red-mute);
  border-left-color:var(--red);
  font-weight:600;
}
.nav-icon{font-size:.9rem;width:18px;text-align:center;flex-shrink:0}

/* Sidebar footer */
.sidebar-footer{padding:.9rem 1.1rem;border-top:1px solid var(--border)}
.user-row{display:flex;align-items:center;gap:.65rem;margin-bottom:.75rem}
.user-av{
  width:32px;height:32px;flex-shrink:0;
  background:var(--red);border-radius:8px;
  display:flex;align-items:center;justify-content:center;
  font-family:'Barlow Condensed',sans-serif;font-weight:900;font-size:.9rem;color:#fff;
}
.user-info .uname{font-size:.85rem;font-weight:600}
.user-info .urole{font-size:.68rem;color:var(--white-dim);letter-spacing:.05em}
.btn-logout{
  display:flex;align-items:center;justify-content:center;gap:.4rem;
  width:100%;padding:.5rem;
  background:rgba(224,30,30,.1);
  border:1px solid rgba(224,30,30,.25);
  border-radius:6px;
  color:var(--red);font-size:.78rem;font-weight:600;
  text-decoration:none;transition:all .15s;
}
.btn-logout:hover{background:rgba(224,30,30,.2)}

/* ── MAIN ─────────────────────────────────────── */
.main{margin-left:var(--sidebar-w);flex:1;display:flex;flex-direction:column;min-height:100vh}

.topbar{
  background:var(--black2);
  border-bottom:1px solid var(--border);
  padding:.8rem 1.75rem;
  display:flex;align-items:center;justify-content:space-between;
  position:sticky;top:0;z-index:50;
  border-top:2px solid var(--red);
}
.topbar-left{display:flex;align-items:center;gap:.75rem}
.topbar-icon{
  width:32px;height:32px;
  background:var(--red-mute);
  border:1px solid rgba(224,30,30,.3);
  border-radius:7px;
  display:flex;align-items:center;justify-content:center;font-size:.9rem;
}
.topbar-title{font-family:'Barlow Condensed',sans-serif;font-size:1.15rem;font-weight:800;text-transform:uppercase;letter-spacing:.06em}
.topbar-right{display:flex;align-items:center;gap:1rem}
.topbar-time{font-size:.72rem;color:var(--white-dim);font-family:'Barlow Condensed',sans-serif;letter-spacing:.08em}
.topbar-badge{
  background:var(--red);color:#fff;
  font-family:'Barlow Condensed',sans-serif;font-size:.68rem;font-weight:800;
  padding:.2rem .5rem;border-radius:4px;letter-spacing:.08em;
}

.content{padding:1.75rem;flex:1}

/* ── COMPONENTS ──────────────────────────────── */
.card{
  background:var(--black2);
  border:1px solid var(--border);
  border-radius:10px;
  padding:1.4rem 1.5rem;
  margin-bottom:1.4rem;
  position:relative;overflow:hidden;
}
.card::before{
  content:'';position:absolute;top:0;left:0;right:0;height:2px;
  background:linear-gradient(90deg,var(--red),transparent);
}
.card-title{
  font-family:'Barlow Condensed',sans-serif;
  font-size:.82rem;font-weight:800;
  color:var(--red);text-transform:uppercase;letter-spacing:.12em;
  margin-bottom:1.25rem;
  display:flex;align-items:center;gap:.5rem;
}
.card-title::before{content:'';display:block;width:3px;height:14px;background:var(--red);border-radius:2px}

.grid-2{display:grid;grid-template-columns:1fr 1fr;gap:1.4rem}
.grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:1.4rem}
.grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:1.4rem}

/* Stat card */
.stat-card{
  background:var(--black2);border:1px solid var(--border);
  border-radius:10px;padding:1.1rem 1.25rem;
  position:relative;overflow:hidden;
  transition:border-color .2s;
}
.stat-card:hover{border-color:rgba(224,30,30,.4)}
.stat-card::after{
  content:'';position:absolute;bottom:0;left:0;right:0;height:2px;
  background:linear-gradient(90deg,var(--red),transparent);
  opacity:0;transition:opacity .2s;
}
.stat-card:hover::after{opacity:1}
.stat-icon{font-size:1.4rem;margin-bottom:.5rem}
.stat-value{font-family:'Barlow Condensed',sans-serif;font-size:2rem;font-weight:900;margin-bottom:.1rem;line-height:1}
.stat-label{font-size:.7rem;color:var(--white-dim);letter-spacing:.1em;text-transform:uppercase}

/* Form */
.form-group{margin-bottom:1rem}
.form-group label{display:block;font-size:.7rem;font-weight:700;color:var(--white-dim);text-transform:uppercase;letter-spacing:.1em;margin-bottom:.4rem}
.form-group input,.form-group select,.form-group textarea{
  width:100%;background:var(--black3);
  border:1px solid var(--border2);border-radius:7px;
  padding:.65rem .9rem;color:var(--white);
  font-family:'Barlow',sans-serif;font-size:.88rem;
  transition:border-color .2s,box-shadow .2s;
}
.form-group input:focus,.form-group select:focus,.form-group textarea:focus{
  outline:none;border-color:var(--red);box-shadow:0 0 0 3px rgba(224,30,30,.1)
}
.form-group select option{background:#1a1a1a}
.form-group textarea{resize:vertical;min-height:80px}

/* Buttons */
.btn{display:inline-flex;align-items:center;gap:.4rem;padding:.55rem 1rem;border-radius:7px;font-family:'Barlow',sans-serif;font-weight:600;font-size:.84rem;cursor:pointer;border:none;transition:all .15s;text-decoration:none}
.btn-primary{background:var(--red);color:#fff}
.btn-primary:hover{background:var(--red-dark);box-shadow:0 4px 14px var(--red-glow)}
.btn-danger{background:rgba(224,30,30,.12);border:1px solid rgba(224,30,30,.25);color:var(--red)}
.btn-danger:hover{background:rgba(224,30,30,.22)}
.btn-secondary{background:rgba(255,255,255,.06);border:1px solid var(--border2);color:var(--white)}
.btn-secondary:hover{background:rgba(255,255,255,.1)}
.btn-sm{padding:.35rem .7rem;font-size:.78rem}

/* Table */
.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:.84rem}
th{text-align:left;padding:.55rem .9rem;font-size:.68rem;font-weight:700;color:#555;text-transform:uppercase;letter-spacing:.1em;border-bottom:1px solid var(--border)}
td{padding:.65rem .9rem;border-bottom:1px solid rgba(255,255,255,.03);vertical-align:middle}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(224,30,30,.03)}

/* Badge */
.badge{display:inline-flex;align-items:center;padding:.18rem .5rem;border-radius:4px;font-size:.7rem;font-weight:700;letter-spacing:.05em}
.badge-green{background:rgba(52,211,153,.12);color:#34d399}
.badge-red{background:rgba(224,30,30,.12);color:var(--red)}
.badge-yellow{background:rgba(251,191,36,.12);color:#fbbf24}
.badge-blue{background:rgba(99,179,237,.12);color:#63b3ed}

/* Alert */
.alert{padding:.7rem 1rem;border-radius:7px;font-size:.84rem;margin-bottom:1rem}
.alert-success{background:rgba(52,211,153,.08);border:1px solid rgba(52,211,153,.25);border-left:3px solid #34d399;color:#34d399}
.alert-error{background:rgba(224,30,30,.08);border:1px solid rgba(224,30,30,.25);border-left:3px solid var(--red);color:var(--red)}
.alert-info{background:rgba(224,30,30,.06);border:1px solid rgba(224,30,30,.2);border-left:3px solid var(--red);color:#ffaaaa}

/* Modal */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.8);z-index:200;align-items:center;justify-content:center}
.modal-overlay.active{display:flex}
.modal{background:var(--black2);border:1px solid var(--border);border-top:3px solid var(--red);border-radius:12px;padding:1.75rem;width:100%;max-width:460px;max-height:90vh;overflow-y:auto}
.modal-title{font-family:'Barlow Condensed',sans-serif;font-size:1.1rem;font-weight:800;text-transform:uppercase;letter-spacing:.06em;margin-bottom:1.25rem}
.modal-actions{display:flex;gap:.75rem;justify-content:flex-end;margin-top:1.25rem}

/* Scrollbar */
::-webkit-scrollbar{width:4px;height:4px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border2);border-radius:2px}
::-webkit-scrollbar-thumb:hover{background:#444}

@media(max-width:768px){
  .sidebar{transform:translateX(-100%);transition:transform .3s}
  .sidebar.open{transform:translateX(0)}
  .main{margin-left:0}
  .grid-2,.grid-3,.grid-4{grid-template-columns:1fr}
  .content{padding:1rem}
}
</style>
</head>
<body>

<aside class="sidebar">
  <div class="sidebar-brand">
    <div class="brand-row">
      <div class="brand-logo"><img src="/panel/xcode.jpg" alt="Xcode Logo" onerror="this.parentElement.innerHTML='🖥️'"></div>
      <div class="brand-text">
        <div class="name"><span class="r">X</span>code<span class="r">H</span>oster</div>
        <div class="ver">Panel v<?= PANEL_VERSION ?> · xcode.or.id</div>
      </div>
    </div>
  </div>

  <nav class="sidebar-nav">
    <div class="nav-section-label">Menu Utama</div>
    <?php foreach ($menuItems as $page => $item): ?>
    <div class="nav-item <?= $currentPage === $page ? 'active' : '' ?>">
      <a href="<?= $page ?>.php">
        <span class="nav-icon"><?= $item['icon'] ?></span>
        <?= $item['label'] ?>
      </a>
    </div>
    <?php endforeach; ?>
    <div class="nav-section-label" style="margin-top:.5rem">Eksternal</div>
    <div class="nav-item">
      <a href="/phpmyadmin" target="_blank">
        <span class="nav-icon">🔧</span> phpMyAdmin
      </a>
    </div>
  </nav>

  <div class="sidebar-footer">
    <div class="user-row">
      <div class="user-av">A</div>
      <div class="user-info">
        <div class="uname">Admin</div>
        <div class="urole">ADMINISTRATOR</div>
      </div>
    </div>
    <a href="logout.php" class="btn-logout">⏻ &nbsp;Keluar</a>
  </div>
</aside>

<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <div class="topbar-icon"><?= $menuItems[$currentPage]['icon'] ?? '⊞' ?></div>
      <div class="topbar-title"><?= htmlspecialchars($pageTitle ?? 'Panel') ?></div>
    </div>
    <div class="topbar-right">
      <div class="topbar-time"><?= date('d M Y · H:i') ?> WIB</div>
      <div class="topbar-badge">XCODE</div>
    </div>
  </div>
  <div class="content">
