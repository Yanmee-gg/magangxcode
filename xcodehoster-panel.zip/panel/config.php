<?php
/**
 * Xcodehoster Panel - Konfigurasi
 * GNU GPL v3 - xcode.or.id
 */

define('PANEL_VERSION', '1.0.0');
define('PANEL_NAME', 'Xcodehoster Panel');

// Konfigurasi MySQL
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Diisi otomatis saat instalasi
define('DB_NAME', 'xcodehoster_panel');

// Konfigurasi Domain
define('MAIN_DOMAIN', ''); // Diisi saat instalasi

// Konfigurasi Cloudflare
define('CF_ZONE_ID', '');
define('CF_EMAIL', '');
define('CF_API_KEY', '');

// Path
define('HOME_DIR', '/home');
define('APACHE_SITES', '/etc/apache2/sites-available');
define('CGI_BIN', '/usr/lib/cgi-bin');
define('SSL_DIR', '/etc/apache2/ssl');

// Session
session_start();

// Koneksi DB
function getDB(): ?mysqli {
    $db = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($db->connect_error) return null;
    $db->set_charset('utf8mb4');
    return $db;
}

function isLoggedIn(): bool {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: index.php');
        exit;
    }
}

function runCmd(string $cmd): array {
    exec($cmd . ' 2>&1', $output, $code);
    return ['output' => implode("\n", $output), 'code' => $code];
}

function jsonResponse(array $data): void {
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}
