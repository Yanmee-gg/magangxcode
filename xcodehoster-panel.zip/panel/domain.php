<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Domain Manager';

$msg = ''; $msgType = '';

// Tambah subdomain
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_subdomain') {
  $sub    = preg_replace('/[^a-z0-9\-]/', '', strtolower(trim($_POST['subdomain'] ?? '')));
  $domain = trim($_POST['domain'] ?? MAIN_DOMAIN);
  $ip     = trim($_POST['ip'] ?? '');
  if ($sub && $domain && $ip) {
    // Buat DNS record di Cloudflare
    $cfData = json_encode(['type'=>'A','name'=>$sub,'content'=>$ip,'ttl'=>1,'proxied'=>false]);
    $cfResult = shell_exec("curl -s -X POST \"https://api.cloudflare.com/client/v4/zones/" . CF_ZONE_ID . "/dns_records\" -H \"X-Auth-Email: " . CF_EMAIL . "\" -H \"X-Auth-Key: " . CF_API_KEY . "\" -H \"Content-Type: application/json\" --data '$cfData'");
    // Buat vhost Apache
    $vhostContent = "
<VirtualHost *:80>
    ServerName $sub.$domain
    DocumentRoot /home/$sub
    <Directory /home/$sub>
        Options +ExecCGI
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>";
    file_put_contents(APACHE_SITES . "/$sub.$domain.conf", $vhostContent);
    runCmd("a2ensite $sub.$domain.conf");
    runCmd("service apache2 reload");
    $msg = "Subdomain $sub.$domain berhasil ditambahkan."; $msgType = 'success';
  } else {
    $msg = 'Semua field harus diisi.'; $msgType = 'error';
  }
}

// Hapus domain
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_domain') {
  $conf = basename($_POST['conf'] ?? '');
  $conf = preg_replace('/[^a-zA-Z0-9\.\-_]/', '', $conf);
  if ($conf && file_exists(APACHE_SITES . "/$conf")) {
    runCmd("a2dissite $conf");
    runCmd("rm -f " . APACHE_SITES . "/$conf");
    runCmd("service apache2 reload");
    $msg = "Domain $conf berhasil dihapus."; $msgType = 'success';
  }
}

// Daftar domain aktif
$domains = [];
$confFiles = glob(APACHE_SITES . '/*.conf') ?: [];
foreach ($confFiles as $f) {
  $content = file_get_contents($f);
  preg_match('/ServerName\s+(\S+)/i', $content, $m);
  preg_match('/DocumentRoot\s+(\S+)/i', $content, $dr);
  $enabled = file_exists('/etc/apache2/sites-enabled/' . basename($f));
  $domains[] = [
    'conf'    => basename($f),
    'name'    => $m[1] ?? basename($f, '.conf'),
    'docroot' => $dr[1] ?? '-',
    'enabled' => $enabled,
  ];
}

include 'layout/header.php';
?>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="grid-2">
<!-- Form Tambah Subdomain -->
<div class="card">
  <div class="card-title">Tambah Subdomain</div>
  <form method="POST">
    <input type="hidden" name="action" value="add_subdomain">
    <div class="form-group">
      <label>Nama Subdomain</label>
      <input type="text" name="subdomain" placeholder="contoh: user123" pattern="[a-z0-9\-]+" required>
    </div>
    <div class="form-group">
      <label>Domain Utama</label>
      <input type="text" name="domain" value="<?= htmlspecialchars(MAIN_DOMAIN) ?>" placeholder="yanlie.my.id">
    </div>
    <div class="form-group">
      <label>IP Server</label>
      <input type="text" name="ip" placeholder="103.xxx.xxx.xxx">
    </div>
    <button type="submit" class="btn btn-primary">➕ Tambah Subdomain</button>
  </form>
</div>

<!-- Info DNS -->
<div class="card">
  <div class="card-title">Panduan DNS Cloudflare</div>
  <div style="font-size:.82rem;color:var(--muted);line-height:1.8;font-family:'Space Mono',monospace">
    <p>1. Login ke dashboard Cloudflare</p>
    <p>2. Pilih domain Anda</p>
    <p>3. Klik menu <strong style="color:var(--text)">DNS</strong></p>
    <p>4. Tambah record type <strong style="color:var(--accent)">A</strong></p>
    <p>5. Arahkan ke IP VPS Anda</p>
    <br>
    <p style="color:var(--yellow)">⚠ Pastikan subdomain belum digunakan</p>
  </div>
</div>
</div>

<!-- Daftar Domain -->
<div class="card">
  <div class="card-title" style="justify-content:space-between">
    <span style="display:flex;align-items:center;gap:.5rem"><span style="width:3px;height:14px;background:var(--accent);border-radius:2px;display:block"></span>Domain Terdaftar</span>
    <span class="badge badge-blue"><?= count($domains) ?> domain</span>
  </div>
  <?php if (empty($domains)): ?>
  <p style="color:var(--muted);font-size:.85rem;text-align:center;padding:2rem">Belum ada domain terdaftar.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Domain</th><th>Document Root</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($domains as $i => $d): ?>
        <tr>
          <td style="color:var(--muted)"><?= $i+1 ?></td>
          <td>
            <strong><?= htmlspecialchars($d['name']) ?></strong><br>
            <span style="font-size:.72rem;color:var(--muted);font-family:'Space Mono',monospace"><?= htmlspecialchars($d['conf']) ?></span>
          </td>
          <td style="font-size:.78rem;font-family:'Space Mono',monospace;color:var(--muted)"><?= htmlspecialchars($d['docroot']) ?></td>
          <td><?= $d['enabled'] ? '<span class="badge badge-green">✔ Aktif</span>' : '<span class="badge badge-yellow">⏸ Nonaktif</span>' ?></td>
          <td>
            <form method="POST" style="display:inline" onsubmit="return confirm('Hapus domain ini?')">
              <input type="hidden" name="action" value="delete_domain">
              <input type="hidden" name="conf" value="<?= htmlspecialchars($d['conf']) ?>">
              <button type="submit" class="btn btn-danger btn-sm">🗑️ Hapus</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php include 'layout/footer.php'; ?>
