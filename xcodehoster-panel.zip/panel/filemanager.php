<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'File Manager';

// Tentukan direktori yang diakses
$user    = preg_replace('/[^a-z0-9]/', '', strtolower($_GET['user'] ?? ''));
$baseDir = $user ? "/home/$user" : '/var/www/html';
$baseDir = realpath($baseDir) ?: '/var/www/html';

$msg = ''; $msgType = '';
$currentPath = $baseDir . '/' . ltrim(str_replace('..', '', $_GET['path'] ?? ''), '/');
$currentPath = realpath($currentPath) ?: $baseDir;
// Pastikan tidak keluar dari baseDir
if (strpos($currentPath, $baseDir) !== 0) $currentPath = $baseDir;

$relPath = substr($currentPath, strlen($baseDir));

// Upload file
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'upload' && isset($_FILES['file'])) {
  $fname = basename($_FILES['file']['name']);
  $fname = preg_replace('/[^a-zA-Z0-9\.\-_]/', '_', $fname);
  $dest  = $currentPath . '/' . $fname;
  if (move_uploaded_file($_FILES['file']['tmp_name'], $dest)) {
    chmod($dest, 0777);
    $msg = "File '$fname' berhasil diupload."; $msgType = 'success';
  } else { $msg = 'Upload gagal.'; $msgType = 'error'; }
}

// Buat folder
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'mkdir') {
  $fname = preg_replace('/[^a-zA-Z0-9\.\-_]/', '', $_POST['fname'] ?? '');
  if ($fname) {
    mkdir($currentPath . '/' . $fname, 0777, true);
    $msg = "Folder '$fname' berhasil dibuat."; $msgType = 'success';
  }
}

// Hapus file/folder
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
  $fname = basename($_POST['fname'] ?? '');
  $target = $currentPath . '/' . $fname;
  if (strpos(realpath($target), $baseDir) === 0) {
    if (is_dir($target)) runCmd("rm -rf " . escapeshellarg($target));
    else unlink($target);
    $msg = "'$fname' berhasil dihapus."; $msgType = 'success';
  }
}

// Baca/edit file
$editContent = '';
$editFile = '';
if (isset($_GET['edit'])) {
  $editFile = $currentPath . '/' . basename($_GET['edit']);
  if (file_exists($editFile) && is_file($editFile) && filesize($editFile) < 500000) {
    $editContent = file_get_contents($editFile);
  }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_edit') {
  $fname = basename($_POST['fname'] ?? '');
  $target = $currentPath . '/' . $fname;
  if (strpos(realpath(dirname($target)), $baseDir) === 0) {
    file_put_contents($target, $_POST['content'] ?? '');
    $msg = "File '$fname' berhasil disimpan."; $msgType = 'success';
    $editFile = ''; $editContent = '';
  }
}

// Daftar file
$items = [];
if (is_dir($currentPath)) {
  $entries = scandir($currentPath) ?: [];
  foreach ($entries as $entry) {
    if ($entry === '.') continue;
    $full = $currentPath . '/' . $entry;
    $items[] = [
      'name'    => $entry,
      'isDir'   => is_dir($full),
      'size'    => is_file($full) ? filesize($full) : 0,
      'mtime'   => filemtime($full),
      'perms'   => substr(sprintf('%o', fileperms($full)), -4),
    ];
  }
  usort($items, fn($a,$b) => $b['isDir'] - $a['isDir'] ?: strcmp($a['name'], $b['name']));
}

function formatSize(int $bytes): string {
  if ($bytes >= 1048576) return round($bytes/1048576, 1) . ' MB';
  if ($bytes >= 1024)    return round($bytes/1024, 1) . ' KB';
  return $bytes . ' B';
}

// Breadcrumb
$breadcrumbs = [['label' => basename($baseDir), 'path' => '']];
if ($relPath) {
  $parts = explode('/', trim($relPath, '/'));
  $cum = '';
  foreach ($parts as $p) {
    $cum .= '/' . $p;
    $breadcrumbs[] = ['label' => $p, 'path' => $cum];
  }
}

include 'layout/header.php';
?>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<!-- Toolbar -->
<div class="card" style="padding:1rem 1.5rem">
  <div style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap">
    <!-- Breadcrumb -->
    <div style="flex:1;display:flex;align-items:center;gap:.25rem;font-family:'Space Mono',monospace;font-size:.8rem;flex-wrap:wrap">
      <?php foreach ($breadcrumbs as $i => $bc): ?>
        <?php if ($i > 0): ?><span style="color:var(--muted)">/</span><?php endif; ?>
        <a href="?<?= $user ? 'user='.urlencode($user).'&' : '' ?>path=<?= urlencode($bc['path']) ?>" style="color:<?= $i === count($breadcrumbs)-1 ? 'var(--accent)' : 'var(--muted)' ?>;text-decoration:none"><?= htmlspecialchars($bc['label']) ?></a>
      <?php endforeach; ?>
    </div>
    <!-- Aksi -->
    <button onclick="openModal('modalUpload')" class="btn btn-primary btn-sm">📤 Upload</button>
    <button onclick="openModal('modalMkdir')" class="btn btn-secondary btn-sm">📁 Folder Baru</button>
    <?php if ($user): ?>
    <a href="filemanager.php" class="btn btn-secondary btn-sm">⬅ Kembali</a>
    <?php endif; ?>
  </div>
</div>

<?php if ($editFile): ?>
<!-- Editor -->
<div class="card">
  <div class="card-title">Edit File: <?= htmlspecialchars(basename($editFile)) ?></div>
  <form method="POST">
    <input type="hidden" name="action" value="save_edit">
    <input type="hidden" name="fname" value="<?= htmlspecialchars(basename($editFile)) ?>">
    <textarea name="content" style="width:100%;min-height:400px;background:#0a0e1a;border:1px solid var(--border);border-radius:8px;padding:1rem;color:var(--text);font-family:'Space Mono',monospace;font-size:.82rem;resize:vertical"><?= htmlspecialchars($editContent) ?></textarea>
    <div style="display:flex;gap:.75rem;margin-top:.75rem">
      <button type="submit" class="btn btn-primary">💾 Simpan</button>
      <a href="?<?= $user ? 'user='.urlencode($user).'&' : '' ?>path=<?= urlencode($relPath) ?>" class="btn btn-secondary">Batal</a>
    </div>
  </form>
</div>
<?php else: ?>
<!-- Daftar File -->
<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Nama</th><th>Ukuran</th><th>Dimodifikasi</th><th>Permission</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($items as $item): ?>
        <?php
          $itemRelPath = $relPath . '/' . $item['name'];
          $isParent    = $item['name'] === '..';
          $parentPath  = dirname($relPath);
          $linkPath    = $isParent ? $parentPath : $itemRelPath;
        ?>
        <tr>
          <td>
            <?php if ($item['isDir'] || $isParent): ?>
              <a href="?<?= $user ? 'user='.urlencode($user).'&' : '' ?>path=<?= urlencode($linkPath) ?>" style="color:var(--accent2);text-decoration:none;font-weight:600">
                <?= $isParent ? '📂 ..' : '📁 ' . htmlspecialchars($item['name']) ?>
              </a>
            <?php else: ?>
              <span>📄 <?= htmlspecialchars($item['name']) ?></span>
            <?php endif; ?>
          </td>
          <td style="font-size:.78rem;font-family:'Space Mono',monospace;color:var(--muted)"><?= $item['isDir'] ? '—' : formatSize($item['size']) ?></td>
          <td style="font-size:.78rem;font-family:'Space Mono',monospace;color:var(--muted)"><?= date('d/m/Y H:i', $item['mtime']) ?></td>
          <td><span class="badge badge-blue"><?= $item['perms'] ?></span></td>
          <td>
            <?php if (!$isParent): ?>
            <div style="display:flex;gap:.3rem">
              <?php if (!$item['isDir']): ?>
              <a href="?<?= $user ? 'user='.urlencode($user).'&' : '' ?>path=<?= urlencode($relPath) ?>&edit=<?= urlencode($item['name']) ?>" class="btn btn-secondary btn-sm">✏️</a>
              <?php endif; ?>
              <form method="POST" style="display:inline" onsubmit="return confirm('Hapus <?= htmlspecialchars($item['name']) ?>?')">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="fname" value="<?= htmlspecialchars($item['name']) ?>">
                <button type="submit" class="btn btn-danger btn-sm">🗑️</button>
              </form>
            </div>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- Modal Upload -->
<div class="modal-overlay" id="modalUpload">
  <div class="modal">
    <div class="modal-title">📤 Upload File</div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="action" value="upload">
      <div class="form-group">
        <label>Pilih File</label>
        <input type="file" name="file" required style="color:var(--text)">
      </div>
      <div class="modal-actions">
        <button type="button" onclick="closeModal('modalUpload')" class="btn btn-secondary">Batal</button>
        <button type="submit" class="btn btn-primary">Upload</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Folder Baru -->
<div class="modal-overlay" id="modalMkdir">
  <div class="modal">
    <div class="modal-title">📁 Buat Folder Baru</div>
    <form method="POST">
      <input type="hidden" name="action" value="mkdir">
      <div class="form-group">
        <label>Nama Folder</label>
        <input type="text" name="fname" placeholder="nama-folder" required>
      </div>
      <div class="modal-actions">
        <button type="button" onclick="closeModal('modalMkdir')" class="btn btn-secondary">Batal</button>
        <button type="submit" class="btn btn-primary">Buat</button>
      </div>
    </form>
  </div>
</div>

<?php include 'layout/footer.php'; ?>
