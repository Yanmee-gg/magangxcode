<?php
/**
 * Xcodehoster Panel - Login
 * GNU GPL v3 - xcode.or.id
 */
require_once 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');
    // Kredensial admin dari file konfigurasi
    $adminUser = 'admin';
    $adminPass = file_exists('.admin_pass') ? trim(file_get_contents('.admin_pass')) : 'admin123';
    if ($user === $adminUser && $pass === $adminPass) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user'] = $user;
        header('Location: dashboard.php');
        exit;
    } else {
        $error = 'Username atau password salah.';
    }
}

if (isLoggedIn()) { header('Location: dashboard.php'); exit; }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Xcodehoster Panel — Login</title>
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;600;700;800&family=Space+Mono&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --bg:#07090f;--panel:#0d1117;--border:#1c2433;
  --accent:#2dd4bf;--accent2:#818cf8;
  --text:#f1f5f9;--muted:#64748b;--red:#f87171;
  --green:#34d399;
}
body{
  font-family:'Outfit',sans-serif;
  background:var(--bg);
  color:var(--text);
  min-height:100vh;
  display:flex;align-items:center;justify-content:center;
  background-image:
    radial-gradient(ellipse 80% 50% at 50% -20%,rgba(45,212,191,.12),transparent),
    radial-gradient(ellipse 60% 40% at 80% 80%,rgba(129,140,248,.08),transparent);
}
.wrap{width:100%;max-width:420px;padding:1rem}
.brand{text-align:center;margin-bottom:2rem}
.brand-logo{
  width:60px;height:60px;
  background:linear-gradient(135deg,var(--accent),var(--accent2));
  border-radius:16px;
  display:inline-flex;align-items:center;justify-content:center;
  font-size:1.8rem;margin-bottom:1rem;
  box-shadow:0 0 40px rgba(45,212,191,.25);
}
.brand h1{font-size:1.6rem;font-weight:800;letter-spacing:-.02em}
.brand h1 span{color:var(--accent)}
.brand p{color:var(--muted);font-size:.85rem;font-family:'Space Mono',monospace;margin-top:.25rem}
.card{
  background:var(--panel);
  border:1px solid var(--border);
  border-radius:16px;
  padding:2rem;
}
.form-group{margin-bottom:1.25rem}
.form-group label{
  display:block;font-size:.8rem;font-weight:600;
  color:var(--muted);text-transform:uppercase;
  letter-spacing:.08em;margin-bottom:.5rem;
  font-family:'Space Mono',monospace;
}
.form-group input{
  width:100%;background:rgba(255,255,255,.04);
  border:1px solid var(--border);border-radius:8px;
  padding:.75rem 1rem;color:var(--text);
  font-family:'Space Mono',monospace;font-size:.9rem;
  transition:border-color .2s,box-shadow .2s;
}
.form-group input:focus{
  outline:none;border-color:var(--accent);
  box-shadow:0 0 0 3px rgba(45,212,191,.1);
}
.btn{
  width:100%;padding:.85rem;border:none;border-radius:8px;
  background:linear-gradient(135deg,var(--accent),#0d9488);
  color:#000;font-family:'Outfit',sans-serif;font-weight:700;
  font-size:1rem;cursor:pointer;transition:all .2s;
}
.btn:hover{opacity:.9;transform:translateY(-1px)}
.error{
  background:rgba(248,113,113,.1);border:1px solid rgba(248,113,113,.3);
  border-radius:8px;padding:.75rem 1rem;
  color:var(--red);font-size:.85rem;margin-bottom:1rem;
  font-family:'Space Mono',monospace;
}
.footer{text-align:center;margin-top:1.5rem;color:var(--muted);font-size:.75rem;font-family:'Space Mono',monospace}
.footer a{color:var(--accent);text-decoration:none}
</style>
</head>
<body>
<div class="wrap">
  <div class="brand">
    <div class="brand-logo">🖥️</div>
    <h1>Xcode<span>Hoster</span></h1>
    <p>Panel Admin · xcode.or.id</p>
  </div>
  <div class="card">
    <?php if ($error): ?>
    <div class="error">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="form-group">
        <label>Username</label>
        <input type="text" name="username" placeholder="admin" required autofocus>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn">Masuk ke Panel</button>
    </form>
  </div>
  <div class="footer">
    GNU GPL v3 · <a href="https://xcode.or.id" target="_blank">xcode.or.id</a>
  </div>
</div>
</body>
</html>
