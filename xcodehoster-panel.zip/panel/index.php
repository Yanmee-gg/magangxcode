<?php
/**
 * Xcodehoster Panel - Login
 * GNU GPL v3 - xcode.or.id
 */
require_once 'config.php';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user = trim($_POST['username'] ?? '');
    $pass = trim($_POST['password'] ?? '');
    $adminUser = 'admin';
    $adminPass = file_exists('.admin_pass') ? trim(file_get_contents('.admin_pass')) : 'admin123';
    if ($user === $adminUser && $pass === $adminPass) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user'] = $user;
        header('Location: dashboard.php');
        exit;
    } else { $error = 'Username atau password salah.'; }
}
if (isLoggedIn()) { header('Location: dashboard.php'); exit; }
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Xcodehoster Panel — Login</title>
<link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800;900&family=Barlow:wght@300;400;500;600&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --black:#0a0a0a; --black2:#111; --black3:#1a1a1a;
  --red:#e01e1e; --red-dark:#b51515; --red-glow:rgba(224,30,30,.3);
  --white:#f5f5f5; --white-dim:#aaa; --border:#252525;
}
body{font-family:'Barlow',sans-serif;background:var(--black);color:var(--white);min-height:100vh;display:flex;align-items:center;justify-content:center;overflow:hidden;position:relative}

/* Grid background */
.bg{position:fixed;inset:0;z-index:0;
  background-image:linear-gradient(rgba(224,30,30,.04) 1px,transparent 1px),linear-gradient(90deg,rgba(224,30,30,.04) 1px,transparent 1px);
  background-size:44px 44px}
.bg-glow{position:fixed;width:700px;height:700px;border-radius:50%;
  background:radial-gradient(circle,rgba(224,30,30,.1) 0%,transparent 70%);
  top:50%;left:50%;transform:translate(-50%,-50%);z-index:0;
  animation:pulse 5s ease-in-out infinite}
@keyframes pulse{0%,100%{transform:translate(-50%,-50%) scale(1);opacity:.7}50%{transform:translate(-50%,-50%) scale(1.15);opacity:1}}

/* Corner decorations */
.c{position:fixed;width:80px;height:80px;z-index:1}
.c-tl{top:20px;left:20px;border-top:2px solid var(--red);border-left:2px solid var(--red)}
.c-tr{top:20px;right:20px;border-top:2px solid var(--red);border-right:2px solid var(--red)}
.c-bl{bottom:20px;left:20px;border-bottom:2px solid var(--red);border-left:2px solid var(--red)}
.c-br{bottom:20px;right:20px;border-bottom:2px solid var(--red);border-right:2px solid var(--red)}

/* Ticker tape top */
.ticker{position:fixed;top:0;left:0;right:0;z-index:10;
  background:var(--red);padding:.3rem 0;overflow:hidden;
  font-family:'Barlow Condensed',sans-serif;font-size:.72rem;font-weight:700;
  letter-spacing:.15em;color:#fff}
.ticker-inner{display:flex;gap:4rem;white-space:nowrap;animation:ticker 20s linear infinite}
@keyframes ticker{from{transform:translateX(0)}to{transform:translateX(-50%)}}
.ticker-item{flex-shrink:0}

/* Main wrap */
.wrap{width:100%;max-width:460px;padding:1.5rem;position:relative;z-index:2}

/* Brand / Logo */
.brand{text-align:center;margin-bottom:2rem;animation:fadeDown .5s ease both}
@keyframes fadeDown{from{opacity:0;transform:translateY(-16px)}to{opacity:1;transform:translateY(0)}}

.logo-box{
  display:inline-flex;align-items:center;justify-content:center;
  width:96px;height:96px;
  background:var(--black2);
  border:2px solid var(--red);
  border-radius:22px;
  box-shadow:0 0 40px var(--red-glow),inset 0 1px 0 rgba(255,255,255,.05);
  position:relative;margin-bottom:1.1rem;overflow:hidden;padding:8px;
}
.logo-box img{width:100%;height:100%;object-fit:contain;position:relative;z-index:1;filter:drop-shadow(0 0 6px rgba(224,30,30,.4))}
.logo-box .icon{font-size:3rem;position:relative;z-index:1;filter:drop-shadow(0 0 8px rgba(224,30,30,.5))}

.brand-name{
  font-family:'Barlow Condensed',sans-serif;
  font-size:2.6rem;font-weight:900;
  letter-spacing:.04em;text-transform:uppercase;line-height:1;
}
.brand-name .hi{color:var(--red)}
.brand-sub{
  font-size:.72rem;color:var(--white-dim);
  letter-spacing:.25em;text-transform:uppercase;margin-top:.4rem;
}
.brand-sub span{
  display:inline-block;padding:.15rem .5rem;
  border:1px solid var(--border);border-radius:4px;
  background:rgba(255,255,255,.03);
}

/* Card */
.card{
  background:var(--black2);
  border:1px solid var(--border);
  border-top:3px solid var(--red);
  border-radius:14px;
  padding:2rem;
  box-shadow:0 24px 64px rgba(0,0,0,.7),0 0 0 1px rgba(224,30,30,.08);
  animation:fadeUp .5s .1s ease both;
}
@keyframes fadeUp{from{opacity:0;transform:translateY(16px)}to{opacity:1;transform:translateY(0)}}

.card-title{
  font-family:'Barlow Condensed',sans-serif;
  font-size:1.2rem;font-weight:800;
  text-transform:uppercase;letter-spacing:.08em;
  margin-bottom:.3rem;
}
.card-desc{font-size:.8rem;color:var(--white-dim);margin-bottom:1.5rem}
.divider{height:1px;background:var(--border);margin-bottom:1.5rem}

/* Form */
.fg{margin-bottom:1.1rem}
.fg label{display:block;font-size:.7rem;font-weight:700;color:var(--white-dim);text-transform:uppercase;letter-spacing:.12em;margin-bottom:.45rem}
.input-wrap{position:relative}
.input-icon{position:absolute;left:.85rem;top:50%;transform:translateY(-50%);font-size:.85rem;opacity:.5}
.fg input{
  width:100%;background:var(--black3);
  border:1px solid var(--border);border-radius:8px;
  padding:.72rem 1rem .72rem 2.4rem;
  color:var(--white);font-family:'Barlow',sans-serif;font-size:.9rem;
  transition:border-color .2s,box-shadow .2s;
}
.fg input:focus{outline:none;border-color:var(--red);box-shadow:0 0 0 3px rgba(224,30,30,.12)}
.fg input::placeholder{color:#444}

/* Button */
.btn-login{
  width:100%;padding:.82rem;
  background:var(--red);border:none;border-radius:8px;
  color:#fff;font-family:'Barlow Condensed',sans-serif;
  font-weight:900;font-size:1.05rem;letter-spacing:.15em;text-transform:uppercase;
  cursor:pointer;transition:all .2s;position:relative;overflow:hidden;
}
.btn-login::after{
  content:'';position:absolute;top:0;left:-100%;width:60%;height:100%;
  background:linear-gradient(90deg,transparent,rgba(255,255,255,.2),transparent);
  transform:skewX(-20deg);transition:left .5s;
}
.btn-login:hover{background:var(--red-dark);box-shadow:0 8px 24px var(--red-glow)}
.btn-login:hover::after{left:150%}

/* Error */
.err{background:rgba(224,30,30,.08);border:1px solid rgba(224,30,30,.3);border-left:3px solid var(--red);border-radius:6px;padding:.65rem .9rem;color:#ff7070;font-size:.82rem;margin-bottom:1rem;display:flex;align-items:center;gap:.5rem}

/* Footer */
.footer{text-align:center;margin-top:1.25rem;font-size:.72rem;color:#444;letter-spacing:.04em;animation:fadeUp .5s .25s ease both}
.footer a{color:var(--red);text-decoration:none}
.footer a:hover{text-decoration:underline}
.footer .dot{margin:0 .4rem;color:#333}
</style>
</head>
<body>
<div class="bg"></div>
<div class="bg-glow"></div>
<div class="c c-tl"></div><div class="c c-tr"></div>
<div class="c c-bl"></div><div class="c c-br"></div>

<!-- Ticker -->
<div class="ticker">
  <div class="ticker-inner">
    <?php for($i=0;$i<8;$i++): ?>
    <span class="ticker-item">★ XCODEHOSTER PANEL</span>
    <span class="ticker-item">✦ WEB HOSTING MANAGER</span>
    <span class="ticker-item">★ XCODE.OR.ID</span>
    <span class="ticker-item">✦ GNU GPL V3</span>
    <?php endfor; ?>
  </div>
</div>

<div class="wrap">
  <div class="brand">
    <div class="logo-box">
      <img src="/panel/xcode.jpg" alt="Xcode Logo" onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
      <span class="icon" style="display:none">🖥️</span>
    </div>
    <div class="brand-name"><span class="hi">X</span>code<span class="hi">H</span>oster</div>
    <div class="brand-sub"><span>Panel Admin &nbsp;·&nbsp; v<?= PANEL_VERSION ?></span></div>
  </div>

  <div class="card">
    <div class="card-title">Login Administrator</div>
    <div class="card-desc">Masuk menggunakan akun admin Anda</div>
    <div class="divider"></div>

    <?php if ($error): ?>
    <div class="err">⚠ <?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST">
      <div class="fg">
        <label>Username</label>
        <div class="input-wrap">
          <span class="input-icon">👤</span>
          <input type="text" name="username" placeholder="admin" required autofocus>
        </div>
      </div>
      <div class="fg">
        <label>Password</label>
        <div class="input-wrap">
          <span class="input-icon">🔑</span>
          <input type="password" name="password" placeholder="••••••••" required>
        </div>
      </div>
      <button type="submit" class="btn-login">▶ &nbsp;Masuk</button>
    </form>
  </div>

  <div class="footer">
    <a href="https://xcode.or.id" target="_blank">xcode.or.id</a>
    <span class="dot">·</span>
    <a href="https://github.com/Yanmee-gg/magangxcode" target="_blank">GitHub</a>
    <span class="dot">·</span>
    GNU GPL v3
  </div>
</div>
</body>
</html>
