<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Database Manager';

$msg = ''; $msgType = '';

// Buat database & user baru
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'create') {
  $dbname = preg_replace('/[^a-z0-9_]/', '', strtolower(trim($_POST['dbname'] ?? '')));
  $dbuser = preg_replace('/[^a-z0-9_]/', '', strtolower(trim($_POST['dbuser'] ?? $dbname)));
  $dbpass = trim($_POST['dbpass'] ?? '');
  if ($dbname && $dbpass) {
    $r1 = runCmd("mysql -uroot -e \"CREATE DATABASE IF NOT EXISTS \`$dbname\`;\"");
    $r2 = runCmd("mysql -uroot -e \"CREATE USER IF NOT EXISTS '$dbuser'@'localhost' IDENTIFIED BY '$dbpass';\"");
    $r3 = runCmd("mysql -uroot -e \"GRANT ALL PRIVILEGES ON \`$dbname\`.* TO '$dbuser'@'localhost'; FLUSH PRIVILEGES;\"");
    if ($r1['code'] === 0) {
      $msg = "Database '$dbname' dan user '$dbuser' berhasil dibuat."; $msgType = 'success';
    } else {
      $msg = "Gagal: " . $r1['output']; $msgType = 'error';
    }
  } else { $msg = 'Nama database dan password harus diisi.'; $msgType = 'error'; }
}

// Hapus database
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
  $dbname = preg_replace('/[^a-z0-9_]/', '', strtolower(trim($_POST['dbname'] ?? '')));
  $dbuser = preg_replace('/[^a-z0-9_]/', '', strtolower(trim($_POST['dbuser'] ?? $dbname)));
  if ($dbname) {
    runCmd("mysql -uroot -e \"DROP DATABASE IF EXISTS \`$dbname\`; DROP USER IF EXISTS '$dbuser'@'localhost'; FLUSH PRIVILEGES;\"");
    $msg = "Database '$dbname' berhasil dihapus."; $msgType = 'success';
  }
}

// Ambil daftar database (kecuali sistem)
$dbs = [];
$systemDBs = ['information_schema','performance_schema','mysql','sys'];
$result = shell_exec("mysql -uroot -e 'SHOW DATABASES;' 2>/dev/null");
if ($result) {
  $lines = array_filter(explode("\n", $result));
  foreach ($lines as $line) {
    $line = trim($line);
    if ($line && $line !== 'Database' && !in_array($line, $systemDBs)) {
      // Cek user terkait
      $userResult = shell_exec("mysql -uroot -e \"SELECT User FROM mysql.db WHERE Db='$line' LIMIT 1;\" 2>/dev/null");
      $userLines = array_filter(explode("\n", $userResult ?? ''));
      $dbUser = count($userLines) > 1 ? trim($userLines[1]) : $line;
      // Ukuran database
      $sizeResult = shell_exec("mysql -uroot -e \"SELECT ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) AS size FROM information_schema.tables WHERE table_schema = '$line';\" 2>/dev/null");
      $sizeLines = array_filter(explode("\n", $sizeResult ?? ''));
      $size = count($sizeLines) > 1 ? trim($sizeLines[1]) : '0';
      $dbs[] = ['name' => $line, 'user' => $dbUser, 'size' => ($size ?: '0') . ' MB'];
    }
  }
}

include 'layout/header.php';
?>

<?php if ($msg): ?>
<div class="alert alert-<?= $msgType ?>"><?= htmlspecialchars($msg) ?></div>
<?php endif; ?>

<div class="grid-2">
<div class="card">
  <div class="card-title">Buat Database Baru</div>
  <form method="POST">
    <input type="hidden" name="action" value="create">
    <div class="form-group">
      <label>Nama Database</label>
      <input type="text" name="dbname" placeholder="contoh: user_db" pattern="[a-z0-9_]+" required>
    </div>
    <div class="form-group">
      <label>Username DB (opsional, default = nama database)</label>
      <input type="text" name="dbuser" placeholder="kosongkan = sama dengan nama database" pattern="[a-z0-9_]*">
    </div>
    <div class="form-group">
      <label>Password DB</label>
      <input type="password" name="dbpass" placeholder="Buat password" required>
    </div>
    <button type="submit" class="btn btn-primary">➕ Buat Database</button>
  </form>
</div>

<div class="card">
  <div class="card-title">Akses phpMyAdmin</div>
  <p style="color:var(--muted);font-size:.85rem;margin-bottom:1rem">Kelola database secara visual melalui phpMyAdmin.</p>
  <a href="/phpmyadmin" target="_blank" class="btn btn-secondary" style="display:inline-flex">
    🔧 Buka phpMyAdmin
  </a>
  <div style="margin-top:1rem;font-size:.78rem;color:var(--muted);font-family:'Space Mono',monospace">
    <p>Login dengan user root atau user database yang dibuat.</p>
  </div>
</div>
</div>

<div class="card">
  <div class="card-title" style="justify-content:space-between">
    <span style="display:flex;align-items:center;gap:.5rem"><span style="width:3px;height:14px;background:var(--accent);border-radius:2px;display:block"></span>Daftar Database</span>
    <span class="badge badge-blue"><?= count($dbs) ?> database</span>
  </div>
  <?php if (empty($dbs)): ?>
  <p style="color:var(--muted);font-size:.85rem;text-align:center;padding:2rem">Belum ada database.</p>
  <?php else: ?>
  <div class="table-wrap">
    <table>
      <thead><tr><th>#</th><th>Nama Database</th><th>Username</th><th>Ukuran</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($dbs as $i => $db): ?>
        <tr>
          <td style="color:var(--muted)"><?= $i+1 ?></td>
          <td><strong style="font-family:'Space Mono',monospace"><?= htmlspecialchars($db['name']) ?></strong></td>
          <td style="font-size:.82rem;font-family:'Space Mono',monospace;color:var(--muted)"><?= htmlspecialchars($db['user']) ?></td>
          <td><span class="badge badge-blue"><?= htmlspecialchars($db['size']) ?></span></td>
          <td>
            <form method="POST" style="display:inline" onsubmit="return confirm('Hapus database <?= htmlspecialchars($db['name']) ?>? Semua data akan hilang!')">
              <input type="hidden" name="action" value="delete">
              <input type="hidden" name="dbname" value="<?= htmlspecialchars($db['name']) ?>">
              <input type="hidden" name="dbuser" value="<?= htmlspecialchars($db['user']) ?>">
              <button type="submit" class="btn btn-danger btn-sm">🗑️ Hapus</button>
            </form>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
  <?php endif; ?>
</div>

<?php include 'layout/footer.php'; ?>
