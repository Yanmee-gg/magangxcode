<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Tentang Panel';
include 'layout/header.php';
?>

<div class="grid-2">
<div class="card">
  <div class="card-title">Tentang Xcodehoster Panel</div>
  <div style="text-align:center;padding:1rem 0 1.5rem">
    <div style="width:72px;height:72px;background:linear-gradient(135deg,var(--accent),var(--accent2));border-radius:18px;display:inline-flex;align-items:center;justify-content:center;font-size:2rem;margin-bottom:1rem;box-shadow:0 0 40px rgba(45,212,191,.2)">🖥️</div>
    <h2 style="font-size:1.4rem;font-weight:800">Xcodehoster Panel</h2>
    <p style="color:var(--muted);font-family:'Space Mono',monospace;font-size:.8rem;margin-top:.25rem">Versi <?= PANEL_VERSION ?></p>
  </div>
  <table style="font-size:.85rem">
    <tr><td style="color:var(--muted);width:140px;padding:.4rem 0">Versi</td><td><?= PANEL_VERSION ?></td></tr>
    <tr><td style="color:var(--muted);padding:.4rem 0">Berdasarkan</td><td>Xcodehoster v11</td></tr>
    <tr><td style="color:var(--muted);padding:.4rem 0">Lisensi</td><td><a href="LICENSE" target="_blank" style="color:var(--accent)">GNU GPL v3</a></td></tr>
    <tr><td style="color:var(--muted);padding:.4rem 0">Website</td><td><a href="https://xcode.or.id" target="_blank" style="color:var(--accent)">xcode.or.id</a></td></tr>
    <tr><td style="color:var(--muted);padding:.4rem 0">GitHub</td><td><a href="https://github.com/kurniawandata/xcodehoster" target="_blank" style="color:var(--accent)">kurniawandata/xcodehoster</a></td></tr>
    <tr><td style="color:var(--muted);padding:.4rem 0">PHP Versi</td><td><?= phpversion() ?></td></tr>
  </table>
</div>

<div class="card">
  <div class="card-title">Tim Pengembang</div>

  <div style="margin-bottom:1.25rem">
    <p style="font-size:.72rem;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;font-family:'Space Mono',monospace;margin-bottom:.75rem">Tim Inti X-Code Media</p>
    <div style="display:flex;flex-direction:column;gap:.75rem">
      <div style="display:flex;align-items:center;gap:.75rem;padding:.75rem;background:rgba(255,255,255,.03);border-radius:8px;border:1px solid var(--border)">
        <div style="width:40px;height:40px;background:linear-gradient(135deg,var(--accent),#0d9488);border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:800;color:#000;flex-shrink:0">K</div>
        <div>
          <div style="font-weight:700">Kurniawan</div>
          <div style="font-size:.75rem;color:var(--muted);font-family:'Space Mono',monospace">Lead Developer · Back End</div>
          <div style="font-size:.72rem;color:var(--muted)">kurniawanajazenfone@gmail.com</div>
        </div>
      </div>
      <div style="display:flex;align-items:center;gap:.75rem;padding:.75rem;background:rgba(255,255,255,.03);border-radius:8px;border:1px solid var(--border)">
        <div style="width:40px;height:40px;background:linear-gradient(135deg,var(--accent2),#6d28d9);border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:800;color:#fff;flex-shrink:0">H</div>
        <div>
          <div style="font-weight:700">Hermawan</div>
          <div style="font-size:.75rem;color:var(--muted);font-family:'Space Mono',monospace">Front End Designer</div>
          <div style="font-size:.72rem;color:var(--muted)">hermawan9815@gmail.com</div>
        </div>
      </div>
    </div>
  </div>

  <div>
    <p style="font-size:.72rem;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;font-family:'Space Mono',monospace;margin-bottom:.75rem">Tim Magang</p>
    <div style="display:flex;align-items:center;gap:.75rem;padding:.75rem;background:rgba(45,212,191,.05);border-radius:8px;border:1px solid rgba(45,212,191,.2)">
      <div style="width:40px;height:40px;background:linear-gradient(135deg,#f59e0b,#d97706);border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:800;color:#000;flex-shrink:0">W</div>
      <div>
        <div style="font-weight:700">Wayan Juliana</div>
        <div style="font-size:.75rem;color:var(--muted);font-family:'Space Mono',monospace">PHP Panel Developer · 2025</div>
        <div style="font-size:.72rem;color:var(--muted)">Politeknik Negeri Lampung</div>
        <div style="font-size:.72rem;color:var(--accent);margin-top:.2rem">Web Installer · Panel Hosting Mini</div>
      </div>
    </div>
  </div>
</div>
</div>

<div class="card">
  <div class="card-title">Lisensi & Atribusi</div>
  <div style="font-size:.85rem;line-height:1.8;color:var(--muted)">
    <p>Aplikasi ini dirilis di bawah lisensi <strong style="color:var(--text)">GNU General Public License v3 (GPL v3)</strong>.</p>
    <p style="margin-top:.5rem">Panel ini memanfaatkan komponen file manager yang berlisensi GPL v3:</p>
    <a href="https://github.com/kurniawandata/xcodehoster/blob/main/filemanager/LICENSE" target="_blank"
       style="display:inline-flex;align-items:center;gap:.5rem;margin-top:.5rem;color:var(--accent);font-family:'Space Mono',monospace;font-size:.78rem">
      🔗 github.com/kurniawandata/xcodehoster — filemanager/LICENSE
    </a>
    <p style="margin-top:1rem">Anda bebas untuk menggunakan, memodifikasi, dan mendistribusikan ulang aplikasi ini selama mengikuti ketentuan GPL v3.</p>
    <div style="margin-top:1rem">
      <a href="LICENSE" target="_blank" class="btn btn-secondary btn-sm">📄 Lihat File LICENSE</a>
      <a href="CONTRIBUTORS.md" target="_blank" class="btn btn-secondary btn-sm" style="margin-left:.5rem">👥 Lihat CONTRIBUTORS</a>
    </div>
  </div>
</div>

<?php include 'layout/footer.php'; ?>
